# Wine-Quality-Prediction-using-Machine-Learning
This project is about creating a machine learning algorithm that can predict the quality of wine based on the given dataset.
Different machine learning algorithms such as logistic regression, decision tree and random forest are compared to see which model gives the best accuracy. 
To see the complete video explanation of this project, check out the following link :>> https://youtu.be/UkzV1e4tRyk
